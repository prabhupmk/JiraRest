package JiraChaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DeleteRequest extends Basejira{
	
	@Test (dependsOnMethods = "JiraChaining.UpdateTicket.sendPutRequest")
	public void SendDeleteRequest() {
	
	RestAssured.baseURI = "https://restapitesting.atlassian.net/rest/api/2/issue/";
	
	RequestSpecification inputRequest = RestAssured
            .given()
            .auth()
			.preemptive()
			.basic("smariappanmech@gmail.com", "pZfvTDq7DEY2XVVOu87cB256");
	
	Response response =inputRequest.delete(id);
	
	response.prettyPrint();
	System.out.println(response.getStatusCode());
	
	response.then().assertThat().statusCode(204);


	}
}



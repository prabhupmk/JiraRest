package JiraChaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllTickets extends Basejira {
	@Test (dependsOnMethods = "JiraChaining.CreateTicket.sendPostRequest")
	public void sendGetRequest() {
		
		RestAssured.baseURI = "https://restapitesting.atlassian.net/rest/api/2/search?JQL=project='TES'";


		RequestSpecification inputRequest = RestAssured
				                            .given()
				                            .param("maxResults", "2")
				                            .auth()
				                            .preemptive()
				                            .basic("smariappanmech@gmail.com", "pZfvTDq7DEY2XVVOu87cB256");
//				                            .contentType(ContentType.JSON)
//				                            .accept(ContentType.JSON);
		
		Response GetResponse = inputRequest.get();

		//validate response
		GetResponse.prettyPrint();
		System.out.println("Status code:" +GetResponse.statusCode());
	}

}

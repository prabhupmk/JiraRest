package JiraChaining;



import org.testng.annotations.Test;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateTicket extends Basejira {

		
		@Test (dependsOnMethods = "JiraChaining.GetAllTickets.sendGetRequest")
		public void sendPutRequest() {
			RestAssured.baseURI = "https://restapitesting.atlassian.net/rest/api/2/issue/";
			

			RequestSpecification inputRequest = RestAssured
							.given()
							.auth()
							.preemptive()
							.basic("smariappanmech@gmail.com", "pZfvTDq7DEY2XVVOu87cB256")
							.contentType(ContentType.JSON)
							.body("{\r\n" + 
									"\"fields\": {\r\n" + 											
									"\"description\": \"Description updated via RestAssured via PUT\"\r\n" + 					
									"}\r\n" + 
									"}");
					
			
			Response response = inputRequest.put(id);
			response.prettyPrint();
			System.out.println(response.getStatusCode());
			
//			String description = response.jsonPath().get("description");
//			System.out.println("DESC:" +description);
			
			response.then().assertThat().statusCode(200);
		}
	}


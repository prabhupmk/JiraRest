package JiraChaining;

public class Basejira {
	
	public static String id;
}
